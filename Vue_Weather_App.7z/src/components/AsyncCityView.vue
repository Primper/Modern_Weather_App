<template>
    <div class="w-full flex flex-col flex-1 justify-between
    px-[7vw] tablet:px-[6vw] desktop:px-[4vw]
    py-[7vw] tablet:py-[6vw] desktop:py-[4vw]">
      <!-- Header -->
      <div class="flex flex-row justify-center items-center relative">
        <RouterLink :to="{ name: 'home' }">
          <div class="flex text-gray-400
          bg-[#212121]
          px-[3vw] py-[3vw] mobile:px-[3vw] mobile:py-[3vw] tablet:px-[2vw] tablet:py-[2vw] desktop:px-[1vw] desktop:py-[1vw]
          rounded-full
          focus-within:text-white">
            <i class="fa-solid fa-magnifying-glass relative pointer-events-none
        text-[3.7vw] leading-[3.7vw] mobile:text-[3.7vw] mobile:leading-[3.7vw] tablet:text-[2.4vw] tablet:leading-[2.4vw] desktop:text-[1.4vw] desktop:leading-[1.4vw]
        transition ease-in-out duration-300"></i>
          </div>
        </RouterLink>
        <a class="text-white text-left w-full select-none
        ml-[3vw] mobile:ml-[3vw] tablet:ml-[2vw] desktop:ml-[2vw]
        text-[2.4vw] leading-[2.5vw] mobile:text-[2.4vw] mobile:leading-[2.5vw] tablet:text-[2.1vw] tablet:leading-[2.3vw] desktop:text-[0.9vw] desktop:leading-[1.1vw]">
        👈 by this little button you can come back to main screen -_-
        </a>
      </div>
      <!-- Main Block -->
      <div class="flex flex-1 flex-col w-full justify-between
      desktop:flex-row 
      text-white
      text-[3.1vw] leading-[3.1vw] mobile:text-[2.7vw] mobile:leading-[2.7vw] tablet:text-[2.2vw] tablet:leading-[2.2vw] desktop:text-[1vw] desktop:leading-[1vw]
      mt-[6vw] mobile:mt-[6vw] tablet:mt-[5vw] desktop:mt-[3vw]">
        <!-- Left Block -->
        <div class="flex flex-[0_1_100%] flex-col
        desktop:flex-[0_1_32%] 
        px-[8vw] mobile:px-[7vw] tablet:px-[6vw] desktop:px-[2.5vw]
        py-[8vw] mobile:py-[7vw] tablet:py-[6vw] desktop:py-[2.5vw]
        bg-[#212121] rounded-[2vw]">
          <div class="flex flex-1 flex-col
          after:w-full after:h-[2px] after:bg-gray-400 after:opacity-30
          after:mt-[8vw] mobile:after:mt-[7vw] tablet:after:mt-[6vw] desktop:after:mt-[1vw]">
            <div class="flex flex-1 flex-row justify-between">
              <a>
              {{
              new Date(weatherData.currentTime).toLocaleDateString(
              "en-us",
              {
                weekday: "long",
               }
              )
              }},
              <span class="text-gray-400">
                {{
                new Date(weatherData.currentTime).toLocaleDateString(
                "en-us",
                {
                  day: "2-digit",
                  month: "long",
                }
                )
                }}
              </span>
              </a>
              <a class="text-gray-400">
                {{
                new Date(weatherData.currentTime).toLocaleTimeString(
                "en-us",
                {
                  timeStyle: "short",
                }
                )
                }}
              </a>
            </div>
            <a class="w-full flex flex-row items-center justify-center
            mt-[8vw] mobile:mt-[7vw] tablet:mt-[6vw] desktop:mt-[2vw]
            text-[18vw] leading-[18vw] mobile:text-[17vw] mobile:leading-[17vw] tablet:text-[16vw] tablet:leading-[16vw] desktop:text-[6vw] desktop:leading-[6vw]
            ">
            {{ Math.round(weatherData.current.temp) }}&deg;
            </a>
            <div class="w-full flex flex-row items-center justify-center text-gray-400">
              <i class="fa-solid fa-temperature-three-quarters relative pointer-events-none
              text-[3.7vw] leading-[3.7vw] mobile:ml-[4vw] mobile:text-[3.7vw] mobile:leading-[3.7vw] tablet:ml-[2.5vw] tablet:text-[2.4vw] tablet:leading-[2.4vw] desktop:ml-[1.6vw] desktop:text-[1.4vw] desktop:leading-[1.4vw]
              transition ease-in-out duration-300"></i>
              <a class="px-[2.5vw] mobile:px-[2.5vw] tablet:px-[2vw] desktop:px-[2vw] 
              py-[2vw] mobile:py-[2vw] tablet:py-[2vw] desktop:py-[1vw]
              select-none">
                Feels like
                {{ Math.round(weatherData.current.feels_like) }} &deg;
              </a>
            </div>
          </div>
          <div class="flex flex-1 flex-col">
          </div>
        </div>
        <!-- Right Blocks -->
        <div class="flex flex-[0_1_65%] flex-col
        px-[2vw]
        py-[2vw]
        bg-[#212121] rounded-full">
          asd
          <!-- Right Top Block -->
          <div class="flex flex-col"></div>
          <!-- Right Bottom Block -->
          <div class="flex flex-col"></div>
        </div>
      </div>
    </div>

    <!-- Weather Overview -->
    <div class="flex flex-col items-center text-white py-12">
      <h1 class="text-4xl mb-2">{{ route.params.city }}</h1>
      <p class="text-8xl mb-8">
        {{ Math.round(weatherData.current.temp) }}&deg;
      </p>
      <p class="text-8xl mb-8">
        {{ Math.round(weatherData.current.wind_speed) }}
      </p>
      <p class="text-8xl mb-8">
        {{ Math.round(weatherData.current.humidity) }}
      </p>
      <p class="text-8xl mb-8">
        {{ Math.round(weatherData.current.wind_deg) }}
      </p>
      <p class="text-8xl mb-8">
        {{ Math.round(weatherData.current.pressure) }}
      </p>
      <p class="text-8xl mb-8">
        {{ Math.round(weatherData.current.dew_point) }}
      </p>
      <p>
        Feels like
        {{ Math.round(weatherData.current.feels_like) }} &deg;
      </p>
      <p class="capitalize">
        {{ weatherData.current.weather[0].description }}
      </p>
      <img
        class="w-[150px] h-auto"
        :src="
          `http://openweathermap.org/img/wn/${weatherData.current.weather[0].icon}@2x.png`
        "
        alt=""
      />
    </div>
</template>

<script setup>
import axios from "axios";
import { useRoute } from "vue-router";

//
const route = useRoute();
const getWeatherData = async () => {
  try {
    const weatherData = await axios.get(
      `https://api.openweathermap.org/data/2.5/onecall?lat=${route.query.lat}&lon=${route.query.lng}&exclude={part}&appid=f320dbbf8d967e3217fd850f58e070d4&units=metric`
    );

    

    // cal current date & time
    const localOffset = new Date().getTimezoneOffset() * 60000;
    const utc = weatherData.data.current.dt * 1000 + localOffset;
    weatherData.data.currentTime =
      utc + 1000 * weatherData.data.timezone_offset;

    // cal hourly weather offset
    weatherData.data.hourly.forEach((hour) => {
      const utc = hour.dt * 1000 + localOffset;
      hour.currentTime =
        utc + 1000 * weatherData.data.timezone_offset;
    });

    return weatherData.data;
  } catch (err) {
    console.log(err);
  }
};
const weatherData = await getWeatherData();
console.log(weatherData);

</script>